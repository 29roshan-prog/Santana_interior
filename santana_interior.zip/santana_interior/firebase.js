// ✅ Import the Firebase SDK modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// ✅ Your project config (this is based on your details)
const firebaseConfig = {
  apiKey: "AIzaSyCD75MPt0KSypEOdnB25h5pu1nU-D_fiow",
  authDomain: "santana-interiors.firebaseapp.com",
  projectId: "santana-interiors",
  storageBucket: "santana-interiors.appspot.com",
  messagingSenderId: "556536764492",
  appId: "1:556536764492:web:7f5445a7ee699ce58e7ce9",
  measurementId: "G-GC1BDYFKLX"
};

// ✅ Initialize Firebase and Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ✅ Handle form submit
document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("contact-form");

  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const name = form["name"].value;
    const email = form["email"].value;
    const message = form["message"].value;

    try {
      await addDoc(collection(db, "contacts"), {
        name,
        email,
        message,
        timestamp: new Date()
      });
      console.log("Form submitted to Firestore");
    } catch (err) {
      console.error("Error adding document:", err);
    }
  });
});
